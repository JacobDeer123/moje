public interface ICDCodeTabular {

    String getDescription(String string) throws IndexOutOfBoundsException;

}
